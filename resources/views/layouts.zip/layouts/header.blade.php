<header class="header <?php echo (in_array(basename($_SERVER['PHP_SELF']), array(route('home'),route('gbbm-anniversary-celebration'), route('home-church-worship-and-praise-video'), route('church-planter-pastor')))) ? 'header-alt' : ''; ?>">
  <div class="top-bar">
      <div class="container">
          <div class="row">
              <div class="col-md-4">
                  <div class="top-content">
                      <p>Global Banjara Baptist  Ministries International </p>
                  </div>
              </div>
              <div class="col-md-8">
                  <div class="top-content top-content--right">
                      <a href="mailto:{{ $config['COMPANYEMAIL'] }}"><i class="fas fa-envelope"></i> {{ $config['COMPANYEMAIL'] }} </a>
                  </div>

              </div>
          </div>
      </div>
  </div>

  <div class="main-header">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-md-2">
                  <div class="logo">
                      <a href="{{ route('home') }}" id="logo">
                          <img src="{{ asset($logo->img_path) }}"alt="">
                      </a>
                  </div>
              </div>
              <div class="col-md-10">
                  <div class="main-menu-wrap">
                      <div class="main-menu">
                          <nav>
                              <ul class="subMenuWrapper">
                                  <li><a href="{{ route('about') }}">About GBBMI</a>
                                      <ul class="sub_menu">
                                          <div class="sub-menu-item">
                                              <div class="sub-menu-inner-item">
                                                  <img src="{{ asset('images/about-gbbm-new.jpg') }}" alt="">
                                              </div>
                                              <div class="sub-menu-content">
                                                  <ul>
                                                      <li>
                                                          <a href="{{ route('about') }}">About GBBMI</a>
                                                          <!--<a href="{{ route('about-gbbmi-mission') }}">Our Mission</a>-->
                                                          <a href="{{ route('board-member') }}">Board Members</a>
                                                      </li>
                                                  </ul>
                                              </div>
                                          </div>
                                      </ul>
                                  </li>
                                  <li><a href="{{ route('gbbm-ministry') }}">GBBM Ministry</a>
                                      <ul class="sub_menu">
                                          <div class="sub-menu">
                                              <div class="sub-menu-item">
                                                  <div class="sub-menu-inner-item">
                                                      <img src="{{ asset('images/about.jpg') }}" alt="">
                                                  </div>
                                                  <div class="sub-menu-content">
                                                      <ul>
                                                          <li>
                                                              <a href="{{ route('gbbm-ministry-mission') }}">Ministry Mission</a>
                                                              <a href="{{ asset('documents/gbbm/gbbm-overview.pdf') }}"target="_blank">GBBM Information </a>
                                                              <a href="{{ route('gbbm-founder') }}">GBBM Founders</a>
                                                              <a href="{{ route('gbbm-banjara-people') }}">The Banjara people</a>
                                                              <a href="{{ route('religious-views') }}">Religious Views</a>
                                                              <a href="{{ route('gbbm-accomplishments') }}">Ministry Accomplishments</a>
                                                              <a href="{{ route('gbbm-anniversary-celebration') }}">GBBM's 20th Anniversary Celebration</a>
                                                          </li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          </div>
                                      </ul>
                                  </li>
                                  <li><a href="{{ route('church-planter-pastor') }}">Church Planting Pastors</a>
                                      <ul class="sub_menu">
                                          <div class="sub-menu-item">
                                              <div class="sub-menu-inner-item">
                                                  <img src="{{ asset('images/plastors/2.jpg') }}" alt="">
                                              </div>
                                              <div class="sub-menu-content">
                                                  <ul>
                                                      <li>
                                                          <a href="{{ route('church-planting-pastor-profiles') }}">Church Planting Pastor Profiles</a>
                                                          <a href="{{ route('church-planting-strategy') }}">Church Planting Strategy</a>
                                                          <a href="{{ route('home-churches') }}">Home Churches</a>
                                                          <a href="{{ route('home-church-worship-and-praise-video') }}">Home Church Worship and Praise Video</a>
                                                      </li>
                                                  </ul>

                                              </div>
                                          </div>
                                      </ul>
                                  </li>
                                  <li><a href="{{ route('alethia-banjara-school') }}">Alethia Banjara School</a>
                                      <ul class="sub_menu ">
                                          <div class="sub-menu">
                                              <div class="sub-menu-item">
                                                  <div class="sub-menu-inner-item">
                                                      <img src="{{ asset('images/school.jpg') }}" alt="">
                                                  </div>
                                                  <div class="sub-menu-content">
                                                      <ul>
                                                          <li>
                                                              <a class="pt-5" href="{{ route('school-mission-statement') }}">SCHOOL MISSION STATEMENT</a>
                                                              <a class="pt-5" href="{{ route('about-abs') }}">ABOUT ABS</a>
                                                              <a class="pt-5" href="{{ route('abs-school-information') }}">ABS SCHOOL INFORMATION</a>
                                                              <a class="pt-5" href="{{ route('the-faces-of-abs-students') }}">THE FACES OF ABS STUDENTS</a>
                                                              <a class="pt-5" href="{{ route('teachers-and-class-photos') }}">TEACHERS AND CLASS PHOTOS</a>
                                                          </li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          </div>
                                      </ul>
                                  </li>
                                  <li><a href="{{ route('prayer-warriors') }}">Prayer Warriors</a>
                                      <ul class="sub_menu ">
                                          <div class="sub-menu">
                                              <div class="sub-menu-item">
                                                  <div class="sub-menu-inner-item">
                                                      <img src="{{ asset('images/warriors.png') }}"alt="">
                                                  </div>
                                                  <div class="sub-menu-content">
                                                      <ul>
                                                          <li>
                                                              <a class="pt-5" href="{{ route('prayer-warriors') }}">GBBM Prayer Request</a>
                                                              <a class="pt-5" href="{{ route('sign-up') }}">sign up</a>
                                                              <a class="pt-5" href="{{ route('gbbm-newsletters') }}">GBBM Newsletters </a>
                                                          </li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          </div>
                                      </ul>
                                  </li>
                                  <li><a href="{{ route('donate') }}">Donate</a>
                                      <ul class="sub_menu">
                                          <div class="sub-menu-item">
                                              <div class="sub-menu-inner-item">
                                                  <img src="{{ asset('images/abs-5.jpg') }}" alt="">
                                              </div>
                                              <div class="sub-menu-content">
                                                  <ul>
                                                      <li>
                                                          <a href="{{ route('general-funds') }}">General Fund / Community Development</a>
                                                          <a href="{{ route('sponsor-a-pastor') }}">Sponsor a GBBM Church Planting Pastor</a>
                                                          <a href="{{ route('sponsor') }}">Sponsor an ABS Student</a>
                                                          <a href="{{ route('abs-student-cost-and-benefits') }}"> ABS Student Cost and Benefits</a>
                                                          <a href="{{ route('church-planting-pastor-funds-use') }}"> Church Planting Pastor Funds Use </a>
                                                      </li>
                                                  </ul>
                                              </div>
                                          </div>
                                      </ul>
                                  </li>
                                  <li><a href="{{ route('contact') }}">Contact GBBMI</a></li>
                              </ul>
                          </nav>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</header>