<footer class="footer <?php echo (in_array(basename($_SERVER['PHP_SELF']), array(route('home'),route('home-church-worship-and-praise-video')))) ? 'd-none' : ''; ?>" style="background-image: url({{ asset('images/footer-bg.png') }});">

  <div class="container">
      <div class="row">
          <div class="col-12 col-lg-4 ">
              <div class="footer-info">
                  <a href="">
                      <img src="{{ asset($logo->img_path) }}"alt="">
                      <p>Founded in 2008 to support the Banjara people.</p>
                  </a>
              </div>
          </div>
          <div class="col-12 col-lg-4">
              <div class="footer__nav">
                  <h6>Quick Links</h6>
                  <ul>
                      <li><a href="{{ route('about') }}">About GBBMI</a></li>
                      <li><a href="{{ route('gbbm-ministry') }}"> GBBM Ministry</a></li>
                      <li><a href="{{ route('church-planter-pastor') }}">Church Planting Pastors</a></li>
                      <li><a href="{{ route('alethia-banjara-school') }}">Alethia Banjara School</a></li>
                      <li><a href="{{ route('prayer-warriors') }}">Prayer Warriors</a></li>
                      <li><a href="{{ route('donate') }}">Donate</a></li>
                      <li>
                        @if(Auth::user())
                        <a href="{{ route('dashboard.index') }}">Dashboard</a>                            
                        @else
                        <a href="{{ route('sign-in') }}">Sign In</a>
                        @endif
                    </li>
                  </ul>
              </div>
          </div>
          <div class="col-12 col-lg-4">
              <div class="footer__nav">
                  <h6>Contact Info</h6>
                  <ul>
                      <li><a href="mailto:{{ $config['COMPANYEMAIL'] }}">Email: {{ $config['COMPANYEMAIL'] }}</a></li>
                      <li><a href="#">GBBMI Address: {!! $config['COMPANYADDRESS'] !!}
                        </a></li>
                  </ul>
              </div>
          </div>
          <div class="col-12">
              <div class="footer__copyright text-center">
                  <p>Copyright © 2023 All Rights Reserved</p>
              </div>
          </div>
      </div>
  </div>
</footer>


   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered modal-lg	">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Donate</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="{{ route('stripe.post') }}" method="POST">
                @csrf
                    <div class="donate-form modal-donate-form">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-item">
                                    <input placeholder="First Name" type="text" name="fname" required>
                                    <input type="hidden" name="amount" value="" class="donate-amount">
                                    <input type="hidden" name="pkg_tab" value="" class="pkg-tab">
                                    <input type="hidden" name="donate_type" value="" class="donate-type">
                                    <input type="hidden" name="student_id" value="" class="studet-id">
                                    <input type="hidden" name="pastors" value="" class="pastors-slug">
                                    
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-item">
                                    <input placeholder="Last Name" type="text" name="lname" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-item">
                                    <input placeholder="Email" type="email" name="email" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-item">
                                    <input placeholder="Phone" type="tel" name="phone" required>
                                </div>
                            </div>
                            @php
                                $countries = App\Models\Country::where('sb_faxprice', '<>', '0')->get();    
                            @endphp
                            <div class="col-12">
                                <div class="form-item">
                                    <select name="country" class="form-control">
                                        <option disabled>-- Select Country --</option>
                                        @foreach ($countries as $country)
                                        <option value="{{ $country->id }}">{{ $country->country }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-item">
                                    <textarea placeholder="Message (optional)" name="msg"></textarea>
                                </div>
                            </div>
                            
                            <div class="col-12">
                                <div class="form-item">
                                    <label>Payment Method</label>
                                    <br>
                                    <input type="radio" id="Stripe" name="pay_type" value="Stripe" required>
                                    <label for="Stripe">Stripe</label>
                                    <input type="radio" id="Paypal" name="pay_type" value="Paypal" required>
                                    <label for="Paypal">Paypal</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-item">
                                    <button type="submit" class="btn btn-primary w-100 payment-btn">Continue To
                                        Payment</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
                <div class="pay-form modal-pay-form">
                    <form action="" class="form">
                        <div class="row">
                            <div class="col-12">
                                <div class="form__div">
                                    <input type="text" class="form-control" placeholder=" ">
                                    <label for="" class="form__label">Card Number</label>
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form__div">
                                    <input type="text" class="form-control" placeholder=" ">
                                    <label for="" class="form__label">MM / yy</label>
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form__div">
                                    <input type="password" class="form-control" placeholder=" ">
                                    <label for="" class="form__label">cvv code</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form__div">
                                    <input type="text" class="form-control" placeholder=" ">
                                    <label for="" class="form__label">name on the card</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="btn btn-primary w-100">Sumbit</div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
