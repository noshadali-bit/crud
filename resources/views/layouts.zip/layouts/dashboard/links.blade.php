<link rel="stylesheet" type="text/css" href="{{asset('dash/css/bootstrap.css')}}">

	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
		integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

	<link rel="stylesheet" href="{{asset('dash/css/slick.css')}}" />
	<link rel="stylesheet" href="{{asset('dash/css/slick-theme.css')}}" />
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="stylesheet" type="text/css" href="{{asset('dash/style.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('dash/responsive.css')}}">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
		rel="stylesheet">
		<link href="{{asset('css/jquery.toast.css')}}" rel="stylesheet">
		